import java.util.*;
class temp{
    public static void main(String[] args) {
        System.out.println(calc(8 , 10));
    }
    public static int gcd(int a , int b)
    {
        if(b==0)
            return a;
        return gcd(b , a%b);
    }

    public static int calc(int X , int Y)
    {
        int g = gcd(X , Y);
        int square = g*g;
        int area = X*Y;
        int ans = area/square;
        return ans;
    }
}