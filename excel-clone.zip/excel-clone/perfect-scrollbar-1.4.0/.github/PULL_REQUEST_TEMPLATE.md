Thank you very much for your contribution! Please make sure the followings
are checked.

- [ ] Read [CONTRIBUTING.md](../CONTRIBUTING.md)
- [ ] Run `npm test` to make sure it formats and build successfully
- [ ] Provide the scenario this PR will address(some JSFiddles will be perfect)
  - [perfect-scrollbar JSFiddle](https://jsfiddle.net/utatti/dyvL31r6/)
- [ ] Refer to concerning issues if exist
